## placeholder type specifiers(auto)

### In python typenames are not required

```python
a = 71806291
b = chr(102) + chr(114) + chr(111) + chr(103)
```

### 1.variables
Since C++11

For variables, the type of the variable that is being declared will be automatically deduced from its initializer

##### examples
```cpp
int main()
{
    auto p = 233; // int
    auto q = 2.33; // double
    auto o = 'h'; // char
    auto s = "hello"; // const char *
}
```

### iterator
Using STL more convenient

Since C++11

#### vector
Which one do you prefer?

```cpp
int main()
{
    std::vector <int> v;

    // Three ways to iterate elements in vector

    for (unsigned int i = 0; i < v.size(); i++)
    {
        ...
    }

    std::vector<int>::iterator it;
    for (it = v.begin(); it != v.end(); it++)
    {
        ...
    }

    for (auto it : v)
    {
        ...
    }
}
```

#### set
Which one do you prefer?

```cpp
int main()
{
    std::set<int> s;

    std::set<int>::iterator it;
    for (it = s.begin(); it != s.end(); it++)
    {
        ...
    }
    it = s.lower_bound(233);

    for (auto it : s)
    {
        ...
    }
    auto it = s.lower_bound(233);
}
```

### OOP design

#### code reuse
```cpp
// PI_H
class PI{
    const float val = acos(-1.0);
public:
    double operator * (const double &x)
    {
        return x * val;
    }
}
```

```cpp
// main.cpp
#include "PI.h"

int main()
{
    PI pi;
    float radius = 2.33;
    auto perimeter = 2.0 * (pi * radius);
    std::cout << "size of perimeter is:" << sizeof(perimeter) << std::endl;
}
```

#####result

    size of perimeter is: 8

#### Template
```cpp
template<typename T1, typename T2> inline auto Add(const T1 &t1, const T2 &t2)
{
    auto ret = t1 + t2;
    return ret;
}

int main()
{
    int a = 3;
    long long b = 5;
    float c = 1.0;
    float d = 2.5;
    auto e = Add<int, long long>(a, b); // long long
    auto f = Add(float, float)(c, d); // float

    std::cout << "size of e is: " << sizeof(e) << std::endl;
    std::cout << "size of f is: " << sizeof(f) << std::endl;
}
```

##### result

    size of e is: 8
    size of f is: 4